#!/usr/bin/env python3
"""
Direct camera driver - bypasses usb_cam entirely.
Opens camera with OpenCV and sends directly to ORB-SLAM3.

Author: SMU Drone Club
Date: January 2026
"""

import time
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String, Float64
from cv_bridge import CvBridge


class DirectCameraDriver(Node):
    def __init__(self):
        super().__init__('direct_camera_driver')
        
        # Parameters
        self.declare_parameter("settings_name", "RoverCam")
        self.declare_parameter("device", "/dev/video4")
        self.declare_parameter("width", 640)
        self.declare_parameter("height", 480)
        self.declare_parameter("fps", 30)
        
        self.settings_name = str(self.get_parameter('settings_name').value)
        self.device = str(self.get_parameter('device').value)
        self.width = int(self.get_parameter('width').value)
        self.height = int(self.get_parameter('height').value)
        self.fps = int(self.get_parameter('fps').value)
        
        self.get_logger().info(f"Settings: {self.settings_name}")
        self.get_logger().info(f"Camera device: {self.device}")
        self.get_logger().info(f"Resolution: {self.width}x{self.height} @ {self.fps}fps")
        
        # Open camera directly with OpenCV
        self.cap = cv2.VideoCapture(self.device, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        self.cap.set(cv2.CAP_PROP_FPS, self.fps)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        
        if not self.cap.isOpened():
            self.get_logger().error(f"Failed to open camera {self.device}")
            return
        
        # Verify actual settings
        actual_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        actual_fps = int(self.cap.get(cv2.CAP_PROP_FPS))
        self.get_logger().info(f"Actual: {actual_width}x{actual_height} @ {actual_fps}fps")
        
        self.get_logger().info("Camera opened successfully")
        
        # CvBridge for ROS image conversion
        self.br = CvBridge()
        
        # Handshake state
        self.send_config = True
        self.frame_count = 0
        
        # Publishers (matching ORB-SLAM3 expected topics)
        self.pub_config = self.create_publisher(
            String, '/mono_py_driver/experiment_settings', 1)
        self.pub_img = self.create_publisher(
            Image, '/mono_py_driver/img_msg', 1)
        self.pub_timestep = self.create_publisher(
            Float64, '/mono_py_driver/timestep_msg', 1)
        
        # Subscriber for ACK from ORB-SLAM3
        self.sub_ack = self.create_subscription(
            String, '/mono_py_driver/exp_settings_ack',
            self.ack_callback, 10)
        
        # Timer for sending images at specified FPS
        self.timer = self.create_timer(1.0 / self.fps, self.timer_callback)
        
        self.get_logger().info("Driver initialized, waiting for handshake...")
    
    def ack_callback(self, msg):
        """Handle acknowledgment from ORB-SLAM3 node."""
        if msg.data == "ACK":
            self.send_config = False
            self.get_logger().info("Handshake complete! Starting image stream...")
    
    def timer_callback(self):
        """Called at FPS rate to capture and publish images."""
        # Handshake phase - keep sending config until ACK received
        if self.send_config:
            msg = String()
            msg.data = self.settings_name
            self.pub_config.publish(msg)
            return
        
        # Capture frame from camera
        ret, frame = self.cap.read()
        if not ret or frame is None:
            self.get_logger().warn("Failed to capture frame")
            return
        
        # Create timestamp (nanoseconds as float)
        now = self.get_clock().now()
        timestep = float(now.nanoseconds)
        
        # Publish timestep first (ORB-SLAM3 expects this order)
        timestep_msg = Float64()
        timestep_msg.data = timestep
        self.pub_timestep.publish(timestep_msg)
        
        # Convert and publish image
        img_msg = self.br.cv2_to_imgmsg(frame, encoding="bgr8")
        img_msg.header.stamp = now.to_msg()
        img_msg.header.frame_id = "camera"
        self.pub_img.publish(img_msg)
        
        # Log progress periodically
        self.frame_count += 1
        if self.frame_count % 100 == 0:
            self.get_logger().info(f"Sent {self.frame_count} frames")
    
    def destroy_node(self):
        """Clean up resources."""
        if hasattr(self, 'cap') and self.cap is not None:
            self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = DirectCameraDriver()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down...")
    
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
