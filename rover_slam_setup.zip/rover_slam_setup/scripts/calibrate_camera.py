#!/usr/bin/env python3
"""
Camera calibration script using OpenCV.
Uses checkerboard pattern for intrinsic calibration.

Usage:
    python3 calibrate_camera.py --device /dev/video4 --size 8x6 --square 2.25

Author: SMU Drone Club
Date: January 2026
"""

import cv2
import numpy as np
import os
import yaml
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='Camera Calibration Tool')
    parser.add_argument('--device', type=str, default='/dev/video4',
                        help='Camera device path (default: /dev/video4)')
    parser.add_argument('--size', type=str, default='8x6',
                        help='Checkerboard inner corners as WxH (default: 8x6)')
    parser.add_argument('--square', type=float, default=2.25,
                        help='Square size in cm (default: 2.25)')
    parser.add_argument('--width', type=int, default=640,
                        help='Image width (default: 640)')
    parser.add_argument('--height', type=int, default=480,
                        help='Image height (default: 480)')
    parser.add_argument('--output', type=str, default='~/.ros/camera_info/rover_cam.yaml',
                        help='Output calibration file')
    return parser.parse_args()


def main():
    args = parse_args()
    
    # Parse checkerboard size
    cb_width, cb_height = map(int, args.size.split('x'))
    CHECKERBOARD = (cb_width, cb_height)
    SQUARE_SIZE = args.square / 100.0  # Convert cm to meters
    
    # Termination criteria for corner refinement
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
    
    # Prepare object points (3D points in real world space)
    objp = np.zeros((CHECKERBOARD[0] * CHECKERBOARD[1], 3), np.float32)
    objp[:, :2] = np.mgrid[0:CHECKERBOARD[0], 0:CHECKERBOARD[1]].T.reshape(-1, 2)
    objp *= SQUARE_SIZE
    
    # Arrays to store object points and image points
    objpoints = []  # 3D points in real world space
    imgpoints = []  # 2D points in image plane
    
    # Open camera
    cap = cv2.VideoCapture(args.device, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
    
    if not cap.isOpened():
        print(f"Error: Could not open camera {args.device}")
        print("Available devices:")
        os.system("v4l2-ctl --list-devices")
        return
    
    print("=" * 60)
    print("Camera Calibration Tool")
    print("=" * 60)
    print(f"Device: {args.device}")
    print(f"Resolution: {args.width}x{args.height}")
    print(f"Checkerboard: {CHECKERBOARD[0]}x{CHECKERBOARD[1]} inner corners")
    print(f"Square size: {args.square} cm")
    print()
    print("Instructions:")
    print("  - Press SPACE to capture when checkerboard is detected")
    print("  - Capture 15-30 images from different angles/distances")
    print("  - Press 'c' to calibrate when done (minimum 10 images)")
    print("  - Press 'q' to quit")
    print("=" * 60)
    
    captured = 0
    
    while True:
        ret, frame = cap.read()
        if not ret:
            continue
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Find checkerboard corners
        flags = (cv2.CALIB_CB_ADAPTIVE_THRESH + 
                 cv2.CALIB_CB_FAST_CHECK + 
                 cv2.CALIB_CB_NORMALIZE_IMAGE)
        found, corners = cv2.findChessboardCorners(gray, CHECKERBOARD, flags)
        
        display = frame.copy()
        
        if found:
            # Refine corners to sub-pixel accuracy
            corners2 = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            cv2.drawChessboardCorners(display, CHECKERBOARD, corners2, found)
            cv2.putText(display, "DETECTED - Press SPACE to capture", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        else:
            cv2.putText(display, "Looking for checkerboard...", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        cv2.putText(display, f"Captured: {captured} (need 10+)", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(display, "SPACE=capture  C=calibrate  Q=quit", (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
        
        cv2.imshow('Calibration', display)
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord(' ') and found:
            objpoints.append(objp)
            imgpoints.append(corners2)
            captured += 1
            print(f"Captured image {captured}")
        
        elif key == ord('c'):
            if captured < 10:
                print(f"Need at least 10 images, currently have {captured}")
                continue
                
            print(f"\nCalibrating with {captured} images...")
            
            ret, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
                objpoints, imgpoints, gray.shape[::-1], None, None)
            
            print()
            print("=" * 60)
            print("Calibration Results")
            print("=" * 60)
            print(f"RMS Error: {ret:.4f}")
            if ret < 0.3:
                print("  (Excellent - RMS < 0.3)")
            elif ret < 0.5:
                print("  (Good - RMS < 0.5)")
            else:
                print("  (Consider recalibrating)")
            
            print(f"\nCamera Matrix:")
            print(f"  fx = {camera_matrix[0,0]:.5f} px")
            print(f"  fy = {camera_matrix[1,1]:.5f} px")
            print(f"  cx = {camera_matrix[0,2]:.5f} px")
            print(f"  cy = {camera_matrix[1,2]:.5f} px")
            
            print(f"\nDistortion Coefficients (k1, k2, p1, p2, k3):")
            print(f"  {dist_coeffs.ravel()}")
            
            # Prepare output path
            output_path = os.path.expanduser(args.output)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # Save in ROS camera_info format
            calib_data = {
                'image_width': args.width,
                'image_height': args.height,
                'camera_name': 'rover_cam',
                'camera_matrix': {
                    'rows': 3,
                    'cols': 3,
                    'data': [float(x) for x in camera_matrix.flatten()]
                },
                'distortion_model': 'plumb_bob',
                'distortion_coefficients': {
                    'rows': 1,
                    'cols': 5,
                    'data': [float(x) for x in dist_coeffs.flatten()]
                },
                'rectification_matrix': {
                    'rows': 3,
                    'cols': 3,
                    'data': [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
                },
                'projection_matrix': {
                    'rows': 3,
                    'cols': 4,
                    'data': [
                        float(camera_matrix[0, 0]), 0.0, float(camera_matrix[0, 2]), 0.0,
                        0.0, float(camera_matrix[1, 1]), float(camera_matrix[1, 2]), 0.0,
                        0.0, 0.0, 1.0, 0.0
                    ]
                }
            }
            
            with open(output_path, 'w') as f:
                yaml.dump(calib_data, f, default_flow_style=None)
            
            print(f"\nSaved calibration to: {output_path}")
            
            # Also save ORB-SLAM3 format
            orbslam_config = f"""%YAML:1.0

#--------------------------------------------------------------------------------------------
# Camera Parameters - Calibrated {captured} images, RMS {ret:.4f}
#--------------------------------------------------------------------------------------------
File.version: "1.0"

Camera.type: "PinHole"

Camera1.fx: {camera_matrix[0,0]:.8f}
Camera1.fy: {camera_matrix[1,1]:.8f}
Camera1.cx: {camera_matrix[0,2]:.8f}
Camera1.cy: {camera_matrix[1,2]:.8f}

Camera1.k1: {dist_coeffs[0,0]:.8f}
Camera1.k2: {dist_coeffs[0,1]:.8f}
Camera1.p1: {dist_coeffs[0,2]:.8f}
Camera1.p2: {dist_coeffs[0,3]:.8f}

Camera.width: {args.width}
Camera.height: {args.height}

Camera.newWidth: {args.width}
Camera.newHeight: {args.height}

Camera.fps: 30
Camera.RGB: 1

#--------------------------------------------------------------------------------------------
# ORB Parameters
#--------------------------------------------------------------------------------------------
ORBextractor.nFeatures: 1000
ORBextractor.scaleFactor: 1.2
ORBextractor.nLevels: 8
ORBextractor.iniThFAST: 20
ORBextractor.minThFAST: 7

#--------------------------------------------------------------------------------------------
# Viewer Parameters
#--------------------------------------------------------------------------------------------
Viewer.KeyFrameSize: 0.05
Viewer.KeyFrameLineWidth: 1.0
Viewer.GraphLineWidth: 0.9
Viewer.PointSize: 2.0
Viewer.CameraSize: 0.08
Viewer.CameraLineWidth: 3.0
Viewer.ViewpointX: 0.0
Viewer.ViewpointY: -1.7
Viewer.ViewpointZ: 0.8
Viewer.ViewpointF: -500.0
"""
            orbslam_path = os.path.expanduser('~/RoverCam.yaml')
            with open(orbslam_path, 'w') as f:
                f.write(orbslam_config)
            
            print(f"Saved ORB-SLAM3 config to: {orbslam_path}")
            print("\nCopy RoverCam.yaml to:")
            print("  ~/ros2_test/src/ros2_orb_slam3/orb_slam3/config/Monocular/")
            print("=" * 60)
            break
        
        elif key == ord('q'):
            print("Calibration cancelled")
            break
    
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
