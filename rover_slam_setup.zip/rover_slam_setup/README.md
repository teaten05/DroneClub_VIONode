# RTX Rover Challenge: ORB-SLAM3 Visual Odometry Setup

Complete setup guide for camera + IMU visual-inertial odometry using ORB-SLAM3 on ROS2 Humble.

## Hardware Requirements

| Component | Model | Notes |
|-----------|-------|-------|
| Camera | ELP-USBGS1200P01-SH120 | Global shutter, 120° FOV, USB UVC |
| IMU/Flight Controller | Pixhawk 6C | ICM-42688-P + BMI055 IMUs |
| Computer | Any x86_64 or ARM64 | Ubuntu 22.04, 16GB+ RAM recommended |

## System Requirements

- Ubuntu 22.04 LTS
- ROS2 Humble Hawksbill
- Python 3.10+
- OpenCV 4.2+
- At least 16GB RAM (for building)
- 10GB free disk space

---

## Installation Guide

### Step 1: Install ROS2 Humble

```bash
# Set locale
sudo apt update && sudo apt install locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# Setup sources
sudo apt install software-properties-common
sudo add-apt-repository universe
sudo apt update && sudo apt install curl -y
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS2 Humble
sudo apt update
sudo apt install ros-humble-desktop ros-humble-ros-base ros-dev-tools -y

# Source ROS2
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

### Step 2: Install System Dependencies

```bash
# Essential build tools
sudo apt install -y \
    build-essential \
    cmake \
    git \
    pkg-config \
    python3-pip \
    python3-venv \
    v4l-utils \
    libv4l-dev

# Eigen3 (linear algebra)
sudo apt install -y libeigen3-dev

# OpenCV (should be included with ROS2, but verify)
sudo apt install -y libopencv-dev python3-opencv

# Ceres Solver (optimization library for ORB-SLAM3)
sudo apt install -y libceres-dev

# Other dependencies
sudo apt install -y \
    libglew-dev \
    libboost-all-dev \
    libssl-dev \
    libyaml-cpp-dev
```

### Step 3: Install Pangolin (Visualization Library)

```bash
cd ~/Documents
git clone https://github.com/stevenlovegrove/Pangolin
cd Pangolin

# Install Pangolin dependencies
./scripts/install_prerequisites.sh recommended

# Build and install
cmake -B build
cmake --build build -j4
sudo cmake --install build

# Configure library path
echo 'export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH' >> ~/.bashrc
source ~/.bashrc
sudo ldconfig
```

### Step 4: Install ROS2 Packages

```bash
sudo apt install -y \
    ros-humble-cv-bridge \
    ros-humble-image-transport \
    ros-humble-usb-cam \
    ros-humble-mavros \
    ros-humble-mavros-extras \
    ros-humble-tf2-ros \
    ros-humble-tf2-geometry-msgs

# Install MAVROS geographiclib datasets
sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
```

### Step 5: Create Python Virtual Environment

This is required due to NumPy version conflicts between system packages and ROS2.

```bash
# Create virtual environment
python3 -m venv ~/ros_calib_env

# Activate and install packages
source ~/ros_calib_env/bin/activate
pip install --upgrade pip
pip install numpy==1.26.4 opencv-python pyyaml natsort

deactivate
```

### Step 6: Clone and Build ORB-SLAM3 ROS2 Package

```bash
# Create workspace (MUST be named ros2_test due to hardcoded paths)
mkdir -p ~/ros2_test/src
cd ~/ros2_test/src

# Clone ORB-SLAM3 ROS2 wrapper
git clone https://github.com/Mechazo11/ros2_orb_slam3.git

# Install ROS dependencies
cd ~/ros2_test
rosdep install -r --from-paths src --ignore-src -y --rosdistro humble

# Build (use -j2 if low on RAM)
source /opt/ros/humble/setup.bash
colcon build --symlink-install

# If build freezes due to RAM, add swap space first:
# sudo fallocate -l 8G /swapfile
# sudo chmod 600 /swapfile
# sudo mkswap /swapfile
# sudo swapon /swapfile
# Then rebuild with: colcon build --parallel-workers 1
```

### Step 7: Add User to Video Group

```bash
sudo usermod -aG video $USER
# Log out and log back in for this to take effect
```

---

## Configuration Files

### Camera Calibration File

Create `~/.ros/camera_info/default_cam.yaml`:

```yaml
image_width: 640
image_height: 480
camera_name: rover_cam
camera_matrix:
  rows: 3
  cols: 3
  data: [248.59233, 0.0, 306.49889, 0.0, 248.47562, 245.30856, 0.0, 0.0, 1.0]
distortion_model: plumb_bob
distortion_coefficients:
  rows: 1
  cols: 5
  data: [-0.02483, -0.02641, 0.00072, 0.00068, 0.00738]
rectification_matrix:
  rows: 3
  cols: 3
  data: [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
projection_matrix:
  rows: 3
  cols: 4
  data: [248.59233, 0.0, 306.49889, 0.0, 0.0, 248.47562, 245.30856, 0.0, 0.0, 0.0, 1.0, 0.0]
```

### ORB-SLAM3 Configuration File

Create `~/ros2_test/src/ros2_orb_slam3/orb_slam3/config/Monocular/RoverCam.yaml`:

```yaml
%YAML:1.0

#--------------------------------------------------------------------------------------------
# Camera Parameters - ELP Global Shutter Camera
#--------------------------------------------------------------------------------------------
File.version: "1.0"

Camera.type: "PinHole"

# Camera calibration parameters
Camera1.fx: 248.59233031
Camera1.fy: 248.47561736
Camera1.cx: 306.49888611
Camera1.cy: 245.30855872

Camera1.k1: -0.02482821
Camera1.k2: -0.02640866
Camera1.p1: 0.00071682
Camera1.p2: 0.0006827

# Camera resolution
Camera.width: 640
Camera.height: 480

Camera.newWidth: 640
Camera.newHeight: 480

# Camera frames per second 
Camera.fps: 30

# Color order of the images (0: BGR, 1: RGB)
Camera.RGB: 1

#--------------------------------------------------------------------------------------------
# ORB Parameters
#--------------------------------------------------------------------------------------------

ORBextractor.nFeatures: 1000
ORBextractor.scaleFactor: 1.2
ORBextractor.nLevels: 8
ORBextractor.iniThFAST: 20
ORBextractor.minThFAST: 7

#--------------------------------------------------------------------------------------------
# Viewer Parameters
#--------------------------------------------------------------------------------------------
Viewer.KeyFrameSize: 0.05
Viewer.KeyFrameLineWidth: 1.0
Viewer.GraphLineWidth: 0.9
Viewer.PointSize: 2.0
Viewer.CameraSize: 0.08
Viewer.CameraLineWidth: 3.0
Viewer.ViewpointX: 0.0
Viewer.ViewpointY: -1.7
Viewer.ViewpointZ: 0.8
Viewer.ViewpointF: -500.0
```

---

## Driver Scripts

### Direct Camera Driver

Create `~/ros2_test/src/ros2_orb_slam3/scripts/direct_camera_driver.py`:

```python
#!/usr/bin/env python3
"""
Direct camera driver - bypasses usb_cam entirely.
Opens camera with OpenCV and sends directly to ORB-SLAM3.
"""

import time
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String, Float64
from cv_bridge import CvBridge

class DirectCameraDriver(Node):
    def __init__(self):
        super().__init__('direct_camera_driver')
        
        # Parameters
        self.declare_parameter("settings_name", "RoverCam")
        self.declare_parameter("device", "/dev/video4")
        self.settings_name = str(self.get_parameter('settings_name').value)
        self.device = str(self.get_parameter('device').value)
        
        self.get_logger().info(f"Settings: {self.settings_name}")
        self.get_logger().info(f"Camera device: {self.device}")
        
        # Open camera directly with OpenCV
        self.cap = cv2.VideoCapture(self.device, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
        
        if not self.cap.isOpened():
            self.get_logger().error(f"Failed to open camera {self.device}")
            return
        
        self.get_logger().info("Camera opened successfully")
        
        # CvBridge
        self.br = CvBridge()
        
        # Handshake state
        self.send_config = True
        self.frame_count = 0
        
        # Publishers
        self.pub_config = self.create_publisher(String, '/mono_py_driver/experiment_settings', 1)
        self.pub_img = self.create_publisher(Image, '/mono_py_driver/img_msg', 1)
        self.pub_timestep = self.create_publisher(Float64, '/mono_py_driver/timestep_msg', 1)
        
        # Subscriber for ACK
        self.sub_ack = self.create_subscription(String, '/mono_py_driver/exp_settings_ack', 
                                                 self.ack_callback, 10)
        
        # Timer for sending images at 30Hz
        self.timer = self.create_timer(1.0/30.0, self.timer_callback)
        
        self.get_logger().info("Driver initialized, waiting for handshake...")
    
    def ack_callback(self, msg):
        if msg.data == "ACK":
            self.send_config = False
            self.get_logger().info("Handshake complete! Starting image stream...")
    
    def timer_callback(self):
        # Handshake phase
        if self.send_config:
            msg = String()
            msg.data = self.settings_name
            self.pub_config.publish(msg)
            return
        
        # Capture frame
        ret, frame = self.cap.read()
        if not ret or frame is None:
            self.get_logger().warn("Failed to capture frame")
            return
        
        # Create timestamp (nanoseconds)
        now = self.get_clock().now()
        timestep = float(now.nanoseconds)
        
        # Publish timestep first
        timestep_msg = Float64()
        timestep_msg.data = timestep
        self.pub_timestep.publish(timestep_msg)
        
        # Publish image
        img_msg = self.br.cv2_to_imgmsg(frame, encoding="bgr8")
        img_msg.header.stamp = now.to_msg()
        self.pub_img.publish(img_msg)
        
        self.frame_count += 1
        if self.frame_count % 100 == 0:
            self.get_logger().info(f"Sent {self.frame_count} frames")
    
    def destroy_node(self):
        if self.cap:
            self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = DirectCameraDriver()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
```

Make it executable:
```bash
chmod +x ~/ros2_test/src/ros2_orb_slam3/scripts/direct_camera_driver.py
```

---

## Camera Calibration Script

Create `~/calibrate_camera.py`:

```python
#!/usr/bin/env python3
"""
Camera calibration script using OpenCV.
Uses checkerboard pattern for intrinsic calibration.
"""

import cv2
import numpy as np
import os
import yaml

# Checkerboard configuration
CHECKERBOARD = (8, 6)  # Inner corners (columns, rows)
SQUARE_SIZE = 0.0225   # Square size in meters (2.25 cm)

# Termination criteria for corner refinement
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# Prepare object points
objp = np.zeros((CHECKERBOARD[0] * CHECKERBOARD[1], 3), np.float32)
objp[:, :2] = np.mgrid[0:CHECKERBOARD[0], 0:CHECKERBOARD[1]].T.reshape(-1, 2)
objp *= SQUARE_SIZE

# Arrays to store object points and image points
objpoints = []
imgpoints = []

# Open camera
cap = cv2.VideoCapture('/dev/video4', cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

if not cap.isOpened():
    print("Error: Could not open camera")
    exit()

print("Camera Calibration")
print("==================")
print(f"Checkerboard: {CHECKERBOARD[0]}x{CHECKERBOARD[1]} inner corners")
print(f"Square size: {SQUARE_SIZE*100} cm")
print()
print("Instructions:")
print("  - Press SPACE to capture when checkerboard is detected (green corners)")
print("  - Capture 15-30 images from different angles and distances")
print("  - Press 'c' to calibrate when done")
print("  - Press 'q' to quit")
print()

captured = 0

while True:
    ret, frame = cap.read()
    if not ret:
        continue
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Find checkerboard corners
    found, corners = cv2.findChessboardCorners(gray, CHECKERBOARD, 
                      cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_FAST_CHECK + cv2.CALIB_CB_NORMALIZE_IMAGE)
    
    display = frame.copy()
    
    if found:
        # Refine corners
        corners2 = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
        cv2.drawChessboardCorners(display, CHECKERBOARD, corners2, found)
        cv2.putText(display, "DETECTED - Press SPACE to capture", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    else:
        cv2.putText(display, "Looking for checkerboard...", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    
    cv2.putText(display, f"Captured: {captured}", (10, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    cv2.imshow('Calibration', display)
    
    key = cv2.waitKey(1) & 0xFF
    
    if key == ord(' ') and found:
        objpoints.append(objp)
        imgpoints.append(corners2)
        captured += 1
        print(f"Captured image {captured}")
    
    elif key == ord('c') and captured >= 10:
        print(f"\nCalibrating with {captured} images...")
        
        ret, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
            objpoints, imgpoints, gray.shape[::-1], None, None)
        
        print(f"\nCalibration Results:")
        print(f"RMS Error: {ret:.4f}")
        print(f"\nCamera Matrix:")
        print(f"  fx = {camera_matrix[0,0]:.2f}")
        print(f"  fy = {camera_matrix[1,1]:.2f}")
        print(f"  cx = {camera_matrix[0,2]:.2f}")
        print(f"  cy = {camera_matrix[1,2]:.2f}")
        print(f"\nDistortion Coefficients:")
        print(f"  {dist_coeffs.ravel()}")
        
        # Save calibration
        os.makedirs(os.path.expanduser('~/.ros/camera_info'), exist_ok=True)
        
        calib_data = {
            'image_width': 640,
            'image_height': 480,
            'camera_name': 'rover_cam',
            'camera_matrix': {
                'rows': 3, 'cols': 3,
                'data': camera_matrix.flatten().tolist()
            },
            'distortion_model': 'plumb_bob',
            'distortion_coefficients': {
                'rows': 1, 'cols': 5,
                'data': dist_coeffs.flatten().tolist()
            },
            'rectification_matrix': {
                'rows': 3, 'cols': 3,
                'data': [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
            },
            'projection_matrix': {
                'rows': 3, 'cols': 4,
                'data': [camera_matrix[0,0], 0.0, camera_matrix[0,2], 0.0,
                         0.0, camera_matrix[1,1], camera_matrix[1,2], 0.0,
                         0.0, 0.0, 1.0, 0.0]
            }
        }
        
        with open(os.path.expanduser('~/.ros/camera_info/rover_cam.yaml'), 'w') as f:
            yaml.dump(calib_data, f, default_flow_style=None)
        
        print(f"\nSaved to ~/.ros/camera_info/rover_cam.yaml")
        break
    
    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
```

---

## Running the System

### Step 1: Find Camera Device

```bash
v4l2-ctl --list-devices
```

Look for "Global Shutter Camera" and note the `/dev/video` number.

### Step 2: Start ORB-SLAM3 (Terminal 1)

```bash
cd ~/ros2_test
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run ros2_orb_slam3 mono_node_cpp --ros-args -p node_name_arg:=mono_slam_cpp
```

Wait until it says "Waiting for images".

### Step 3: Start Camera Driver (Terminal 2)

```bash
cd ~/ros2_test
source ~/ros_calib_env/bin/activate
source /opt/ros/humble/setup.bash
source install/setup.bash
python3 src/ros2_orb_slam3/scripts/direct_camera_driver.py --ros-args -p settings_name:=RoverCam -p device:=/dev/video4
```

Adjust `/dev/video4` to match your camera device.

### Step 4: Start IMU (Terminal 3, Optional)

```bash
source /opt/ros/humble/setup.bash
ros2 run mavros mavros_node --ros-args -p fcu_url:=serial:///dev/ttyACM0:921600
```

### Step 5: Initialize SLAM

1. Point camera at a textured scene (books, posters, objects)
2. Slowly move the camera sideways (left-right, ~10-20cm)
3. Watch for "New Map created" in Terminal 1
4. The Pangolin viewer should show green feature points and a 3D map

---

## Troubleshooting

### Camera not found
```bash
# Check available devices
v4l2-ctl --list-devices

# Check device formats
v4l2-ctl -d /dev/video0 --list-formats-ext
```

### Pangolin library not found
```bash
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
sudo ldconfig
```

### NumPy version conflict
Always use the virtual environment:
```bash
source ~/ros_calib_env/bin/activate
```

### Build freezes (RAM issue)
Add swap space:
```bash
sudo fallocate -l 8G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```
Then build with single worker:
```bash
colcon build --parallel-workers 1
```

### Permission denied on camera
```bash
sudo usermod -aG video $USER
# Log out and log back in
```

### SLAM not initializing
- Ensure camera is pointing at textured scene (not plain walls)
- Move camera slowly sideways (translation, not rotation)
- Check lighting is adequate

---

## Jetson Nano Specific Notes

### Additional Steps for ARM64

1. **Use Jetson-specific ROS2 installation:**
   ```bash
   # Follow NVIDIA's ROS2 installation guide for Jetson
   ```

2. **Pangolin may need different build flags:**
   ```bash
   cmake -B build -DCMAKE_BUILD_TYPE=Release
   ```

3. **Reduce ORB features for better performance:**
   Edit `RoverCam.yaml`:
   ```yaml
   ORBextractor.nFeatures: 500  # Reduced from 1000
   ```

4. **Use swap if RAM is limited (4GB Nano):**
   ```bash
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

5. **Camera device path may differ:**
   ```bash
   v4l2-ctl --list-devices
   ```

---

## Project Structure

```
~/ros2_test/
├── src/
│   └── ros2_orb_slam3/
│       ├── orb_slam3/
│       │   ├── config/
│       │   │   └── Monocular/
│       │   │       ├── RoverCam.yaml      # Your camera config
│       │   │       └── EuRoC.yaml         # Example config
│       │   └── Vocabulary/
│       │       └── ORBvoc.txt.bin         # ORB vocabulary
│       └── scripts/
│           └── direct_camera_driver.py    # Camera driver
├── install/
├── build/
└── log/

~/.ros/camera_info/
├── rover_cam.yaml      # Original calibration
└── default_cam.yaml    # Clean format calibration

~/ros_calib_env/        # Python virtual environment
```

---

## License

This project uses ORB-SLAM3 which is licensed under GPLv3.
