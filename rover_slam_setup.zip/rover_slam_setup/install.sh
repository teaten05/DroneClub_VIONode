#!/bin/bash
#
# RTX Rover Challenge - ORB-SLAM3 Visual Odometry Setup Script
# 
# This script installs all dependencies and sets up the ORB-SLAM3
# visual odometry system for the RTX Rover Challenge.
#
# Usage: ./install.sh
#
# Author: SMU Drone Club
# Date: January 2026

set -e  # Exit on error

echo "=============================================="
echo "RTX Rover Challenge - ORB-SLAM3 Setup Script"
echo "=============================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo -e "${RED}Please do not run as root. The script will use sudo when needed.${NC}"
    exit 1
fi

# Detect architecture
ARCH=$(uname -m)
echo "Detected architecture: $ARCH"

if [ "$ARCH" = "aarch64" ]; then
    echo -e "${YELLOW}ARM64 detected (Jetson). Some steps may differ.${NC}"
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# ============================================
# Step 1: Check ROS2 Installation
# ============================================
echo ""
echo "Step 1: Checking ROS2 Humble installation..."

if [ -f "/opt/ros/humble/setup.bash" ]; then
    echo -e "${GREEN}ROS2 Humble found.${NC}"
    source /opt/ros/humble/setup.bash
else
    echo -e "${YELLOW}ROS2 Humble not found. Installing...${NC}"
    
    # Install ROS2 Humble
    sudo apt update && sudo apt install -y locales
    sudo locale-gen en_US en_US.UTF-8
    sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
    export LANG=en_US.UTF-8
    
    sudo apt install -y software-properties-common
    sudo add-apt-repository universe -y
    sudo apt update && sudo apt install -y curl
    sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
    
    sudo apt update
    sudo apt install -y ros-humble-desktop ros-humble-ros-base ros-dev-tools
    
    source /opt/ros/humble/setup.bash
    echo -e "${GREEN}ROS2 Humble installed.${NC}"
fi

# ============================================
# Step 2: Install System Dependencies
# ============================================
echo ""
echo "Step 2: Installing system dependencies..."

sudo apt update
sudo apt install -y \
    build-essential \
    cmake \
    git \
    pkg-config \
    python3-pip \
    python3-venv \
    v4l-utils \
    libv4l-dev \
    libeigen3-dev \
    libopencv-dev \
    python3-opencv \
    libceres-dev \
    libglew-dev \
    libboost-all-dev \
    libssl-dev \
    libyaml-cpp-dev \
    libfuse2

echo -e "${GREEN}System dependencies installed.${NC}"

# ============================================
# Step 3: Install ROS2 Packages
# ============================================
echo ""
echo "Step 3: Installing ROS2 packages..."

sudo apt install -y \
    ros-humble-cv-bridge \
    ros-humble-image-transport \
    ros-humble-usb-cam \
    ros-humble-tf2-ros \
    ros-humble-tf2-geometry-msgs

# Try to install MAVROS (may fail on some systems)
if sudo apt install -y ros-humble-mavros ros-humble-mavros-extras 2>/dev/null; then
    echo -e "${GREEN}MAVROS installed.${NC}"
    # Install geographiclib datasets
    if [ -f "/opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh" ]; then
        sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
    fi
else
    echo -e "${YELLOW}MAVROS installation failed. You may need to install it manually.${NC}"
fi

echo -e "${GREEN}ROS2 packages installed.${NC}"

# ============================================
# Step 4: Install Pangolin
# ============================================
echo ""
echo "Step 4: Installing Pangolin visualization library..."

if [ -d "/usr/local/include/pangolin" ]; then
    echo -e "${GREEN}Pangolin already installed.${NC}"
else
    cd ~/Documents 2>/dev/null || { mkdir -p ~/Documents && cd ~/Documents; }
    
    if [ ! -d "Pangolin" ]; then
        git clone https://github.com/stevenlovegrove/Pangolin
    fi
    
    cd Pangolin
    ./scripts/install_prerequisites.sh recommended || true
    
    cmake -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j$(nproc)
    sudo cmake --install build
    
    echo -e "${GREEN}Pangolin installed.${NC}"
fi

# Configure library path
if ! grep -q "LD_LIBRARY_PATH=/usr/local/lib" ~/.bashrc; then
    echo 'export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH' >> ~/.bashrc
fi
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
sudo ldconfig

# ============================================
# Step 5: Create Python Virtual Environment
# ============================================
echo ""
echo "Step 5: Creating Python virtual environment..."

if [ -d "$HOME/ros_calib_env" ]; then
    echo -e "${GREEN}Virtual environment already exists.${NC}"
else
    python3 -m venv ~/ros_calib_env
    source ~/ros_calib_env/bin/activate
    pip install --upgrade pip
    pip install numpy==1.26.4 opencv-python pyyaml natsort
    deactivate
    echo -e "${GREEN}Virtual environment created.${NC}"
fi

# ============================================
# Step 6: Clone and Build ORB-SLAM3
# ============================================
echo ""
echo "Step 6: Setting up ORB-SLAM3 workspace..."

if [ -d "$HOME/ros2_test/src/ros2_orb_slam3" ]; then
    echo -e "${GREEN}ORB-SLAM3 workspace already exists.${NC}"
else
    mkdir -p ~/ros2_test/src
    cd ~/ros2_test/src
    git clone https://github.com/Mechazo11/ros2_orb_slam3.git
    
    cd ~/ros2_test
    rosdep install -r --from-paths src --ignore-src -y --rosdistro humble || true
fi

# Build (with RAM check)
echo ""
echo "Building ORB-SLAM3 workspace..."
cd ~/ros2_test
source /opt/ros/humble/setup.bash

# Check available RAM
TOTAL_RAM=$(free -g | awk '/^Mem:/{print $2}')
echo "Available RAM: ${TOTAL_RAM}GB"

if [ "$TOTAL_RAM" -lt 8 ]; then
    echo -e "${YELLOW}Low RAM detected. Adding swap space...${NC}"
    
    if [ ! -f /swapfile ]; then
        sudo fallocate -l 8G /swapfile
        sudo chmod 600 /swapfile
        sudo mkswap /swapfile
        sudo swapon /swapfile
    fi
    
    echo "Building with single worker to conserve RAM..."
    colcon build --parallel-workers 1
else
    colcon build --symlink-install
fi

echo -e "${GREEN}ORB-SLAM3 built successfully.${NC}"

# ============================================
# Step 7: Install Configuration Files
# ============================================
echo ""
echo "Step 7: Installing configuration files..."

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Copy camera calibration
mkdir -p ~/.ros/camera_info
if [ -f "$SCRIPT_DIR/config/default_cam.yaml" ]; then
    cp "$SCRIPT_DIR/config/default_cam.yaml" ~/.ros/camera_info/
    echo "Copied default_cam.yaml"
fi

# Copy ORB-SLAM3 config
if [ -f "$SCRIPT_DIR/config/RoverCam.yaml" ]; then
    cp "$SCRIPT_DIR/config/RoverCam.yaml" ~/ros2_test/src/ros2_orb_slam3/orb_slam3/config/Monocular/
    echo "Copied RoverCam.yaml"
fi

# Copy camera driver
if [ -f "$SCRIPT_DIR/scripts/direct_camera_driver.py" ]; then
    cp "$SCRIPT_DIR/scripts/direct_camera_driver.py" ~/ros2_test/src/ros2_orb_slam3/scripts/
    chmod +x ~/ros2_test/src/ros2_orb_slam3/scripts/direct_camera_driver.py
    echo "Copied direct_camera_driver.py"
fi

# Copy calibration script
if [ -f "$SCRIPT_DIR/scripts/calibrate_camera.py" ]; then
    cp "$SCRIPT_DIR/scripts/calibrate_camera.py" ~/
    chmod +x ~/calibrate_camera.py
    echo "Copied calibrate_camera.py"
fi

echo -e "${GREEN}Configuration files installed.${NC}"

# ============================================
# Step 8: Add User to Video Group
# ============================================
echo ""
echo "Step 8: Adding user to video group..."

if groups $USER | grep -q '\bvideo\b'; then
    echo -e "${GREEN}User already in video group.${NC}"
else
    sudo usermod -aG video $USER
    echo -e "${YELLOW}User added to video group. Please log out and log back in.${NC}"
fi

# ============================================
# Step 9: Source Setup in Bashrc
# ============================================
echo ""
echo "Step 9: Updating .bashrc..."

if ! grep -q "source /opt/ros/humble/setup.bash" ~/.bashrc; then
    echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
fi

if ! grep -q "source ~/ros2_test/install/setup.bash" ~/.bashrc; then
    echo "# Source ORB-SLAM3 workspace (uncomment after build)" >> ~/.bashrc
    echo "# source ~/ros2_test/install/setup.bash" >> ~/.bashrc
fi

# ============================================
# Complete
# ============================================
echo ""
echo "=============================================="
echo -e "${GREEN}Installation Complete!${NC}"
echo "=============================================="
echo ""
echo "Next steps:"
echo "  1. Log out and log back in (for video group)"
echo "  2. Find your camera device:"
echo "     v4l2-ctl --list-devices"
echo ""
echo "  3. Run ORB-SLAM3 (Terminal 1):"
echo "     cd ~/ros2_test"
echo "     export LD_LIBRARY_PATH=/usr/local/lib:\$LD_LIBRARY_PATH"
echo "     source /opt/ros/humble/setup.bash"
echo "     source install/setup.bash"
echo "     ros2 run ros2_orb_slam3 mono_node_cpp --ros-args -p node_name_arg:=mono_slam_cpp"
echo ""
echo "  4. Run Camera Driver (Terminal 2):"
echo "     cd ~/ros2_test"
echo "     source ~/ros_calib_env/bin/activate"
echo "     source /opt/ros/humble/setup.bash"
echo "     source install/setup.bash"
echo "     python3 src/ros2_orb_slam3/scripts/direct_camera_driver.py --ros-args -p settings_name:=RoverCam -p device:=/dev/video4"
echo ""
echo "  5. Point camera at textured scene and move slowly sideways"
echo ""
echo "=============================================="
