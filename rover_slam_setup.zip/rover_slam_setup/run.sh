#!/bin/bash
#
# RTX Rover Challenge - Run ORB-SLAM3
#
# Usage: ./run.sh [device]
#   device: Camera device path (default: /dev/video4)
#
# This script starts ORB-SLAM3 and the camera driver in tmux sessions.
# If tmux is not available, it prints instructions for manual startup.

DEVICE=${1:-/dev/video4}

echo "RTX Rover Challenge - ORB-SLAM3"
echo "==============================="
echo "Camera device: $DEVICE"
echo ""

# Check if device exists
if [ ! -e "$DEVICE" ]; then
    echo "Error: Camera device $DEVICE not found"
    echo ""
    echo "Available video devices:"
    v4l2-ctl --list-devices 2>/dev/null || ls /dev/video*
    exit 1
fi

# Export library path
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH

# Check if tmux is available
if command -v tmux &> /dev/null; then
    echo "Starting with tmux..."
    
    # Kill any existing session
    tmux kill-session -t orbslam 2>/dev/null || true
    
    # Create new session with ORB-SLAM3
    tmux new-session -d -s orbslam -n slam
    tmux send-keys -t orbslam:slam "cd ~/ros2_test && export LD_LIBRARY_PATH=/usr/local/lib:\$LD_LIBRARY_PATH && source /opt/ros/humble/setup.bash && source install/setup.bash && ros2 run ros2_orb_slam3 mono_node_cpp --ros-args -p node_name_arg:=mono_slam_cpp" C-m
    
    # Wait for ORB-SLAM3 to initialize
    sleep 5
    
    # Create window for camera driver
    tmux new-window -t orbslam -n camera
    tmux send-keys -t orbslam:camera "cd ~/ros2_test && source ~/ros_calib_env/bin/activate && source /opt/ros/humble/setup.bash && source install/setup.bash && python3 src/ros2_orb_slam3/scripts/direct_camera_driver.py --ros-args -p settings_name:=RoverCam -p device:=$DEVICE" C-m
    
    # Attach to session
    echo ""
    echo "ORB-SLAM3 started in tmux session 'orbslam'"
    echo "  - Window 'slam': ORB-SLAM3 node"
    echo "  - Window 'camera': Camera driver"
    echo ""
    echo "Attaching to session... (Ctrl+B then D to detach)"
    sleep 2
    tmux attach -t orbslam
else
    echo ""
    echo "tmux not found. Please run manually in separate terminals:"
    echo ""
    echo "Terminal 1 (ORB-SLAM3):"
    echo "  cd ~/ros2_test"
    echo "  export LD_LIBRARY_PATH=/usr/local/lib:\$LD_LIBRARY_PATH"
    echo "  source /opt/ros/humble/setup.bash"
    echo "  source install/setup.bash"
    echo "  ros2 run ros2_orb_slam3 mono_node_cpp --ros-args -p node_name_arg:=mono_slam_cpp"
    echo ""
    echo "Terminal 2 (Camera - wait for 'Waiting for images'):"
    echo "  cd ~/ros2_test"
    echo "  source ~/ros_calib_env/bin/activate"
    echo "  source /opt/ros/humble/setup.bash"
    echo "  source install/setup.bash"
    echo "  python3 src/ros2_orb_slam3/scripts/direct_camera_driver.py --ros-args -p settings_name:=RoverCam -p device:=$DEVICE"
    echo ""
    echo "To install tmux: sudo apt install tmux"
fi
